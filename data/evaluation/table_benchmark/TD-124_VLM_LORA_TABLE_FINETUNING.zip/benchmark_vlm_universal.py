#!/usr/bin/env python3
"""Universal VLM Table Benchmark — tests any OpenAI-compatible VLM on complex table PDFs.

Usage:
  VLM_MODEL="Qwen/Qwen2.5-VL-7B-Instruct" python3 /tmp/benchmark_vlm_universal.py
  VLM_MODEL="openbmb/MiniCPM-V-2_6" python3 /tmp/benchmark_vlm_universal.py
  VLM_MODEL="Qwen/Qwen3-VL-8B-Instruct" python3 /tmp/benchmark_vlm_universal.py

Environment variables:
  VLM_MODEL   - HuggingFace model ID (REQUIRED)
  VLM_URL     - vLLM server URL (default: http://localhost:8002)
  MAX_TOKENS  - Max output tokens (default: 4096)
  DOCLING_URL - Docling server URL (default: http://localhost:8080)
"""
import asyncio
import base64
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path("/home/admin/projects/aegisrag/AEGIS_Rag")))

import fitz
import httpx

from src.components.ingestion.table_quality import compute_table_quality
from src.components.ingestion.vlm_table_clients import _parse_html_tables

# Configuration
VLM_URL = os.getenv("VLM_URL", "http://localhost:8002")
VLM_MODEL = os.getenv("VLM_MODEL", "")
DOCLING_URL = os.getenv("DOCLING_URL", "http://localhost:8080")
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "4096"))
BENCH_DIR = Path("/home/admin/projects/aegisrag/AEGIS_Rag/data/evaluation/table_benchmark/complex")

# Model-specific prompts for optimal table extraction
MODEL_PROMPTS = {
    # Qwen family: concise table extraction prompt
    "Qwen/Qwen2.5-VL-7B-Instruct": (
        "Extract all tables from this image. Output each table as HTML "
        "using <table>, <tr>, <th>, <td> tags with rowspan/colspan where needed. "
        "Output only the HTML tables, nothing else."
    ),
    "Qwen/Qwen3-VL-8B-Instruct": (
        "Extract all tables from this image. Output each table as HTML "
        "using <table>, <tr>, <th>, <td> tags with rowspan/colspan where needed. "
        "Output only the HTML tables, nothing else."
    ),
    # NVIDIA RD-TableBench P2 prompt — generic fallback
    "_default": (
        "Convert the image to an HTML table. The output should begin with "
        "<table> and end with </table>. Specify rowspan and colspan attributes "
        "when they are greater than 1. Do not specify any other attributes. "
        "Only use the b, br, tr, th, td, sub and sup HTML tags. "
        "No additional formatting is required."
    ),
}
PROMPT_OVERRIDE = os.getenv("VLM_PROMPT", "")  # Manual override via env var


def build_cells_2d(table_data):
    """Convert Docling table data to 2D cell grid."""
    grid = table_data.get("grid", [])
    if grid:
        return [[c.get("text", "") if isinstance(c, dict) else str(c) for c in row] for row in grid]
    raw = table_data.get("table_cells", table_data.get("cells", []))
    if not raw:
        return []
    nr, nc = table_data.get("num_rows", 0), table_data.get("num_cols", 0)
    if nr == 0 or nc == 0:
        return [[c.get("text", "") if isinstance(c, dict) else str(c) for c in raw]]
    g = [[""] * nc for _ in range(nr)]
    for c in raw:
        if isinstance(c, dict):
            r = c.get("start_row_offset_idx", 0)
            co = c.get("start_col_offset_idx", 0)
            if 0 <= r < nr and 0 <= co < nc:
                g[r][co] = c.get("text", "")
    return g


async def docling_extract(pdf_path):
    """Extract tables via Docling (baseline)."""
    async with httpx.AsyncClient(timeout=300.0) as client:
        with open(pdf_path, "rb") as f:
            resp = await client.post(
                f"{DOCLING_URL}/v1/convert/file",
                files={"files": (os.path.basename(pdf_path), f, "application/pdf")},
                data={"to_formats": "json"},
            )
            resp.raise_for_status()
    result = resp.json()
    jc = result.get("document", {}).get("json_content", {})
    tables = []
    for i, t in enumerate(jc.get("tables", [])):
        td = t.get("data", t)
        cells = build_cells_2d(td)
        if not cells:
            continue
        prov = t.get("prov", [])
        pg = prov[0].get("page_no", 0) if prov else 0
        tables.append({"ref": t.get("self_ref", f"#/tables/{i}"), "page": pg, "cells_2d": cells})
    return tables


async def vlm_page(image_bytes, prompt, timeout=1200.0):
    """Send one page image to the VLM and get parsed tables."""
    b64 = base64.b64encode(image_bytes).decode("utf-8")
    payload = {
        "model": VLM_MODEL,
        "messages": [{"role": "user", "content": [
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
            {"type": "text", "text": prompt},
        ]}],
        "max_tokens": MAX_TOKENS,
        "temperature": 0.0,
    }
    t0 = time.time()
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.post(f"{VLM_URL}/v1/chat/completions", json=payload)
        resp.raise_for_status()
        data = resp.json()
    elapsed = time.time() - t0

    content = data["choices"][0]["message"]["content"]
    usage = data.get("usage", {})
    prompt_tokens = usage.get("prompt_tokens", 0)
    completion_tokens = usage.get("completion_tokens", 0)
    tok_per_sec = completion_tokens / elapsed if elapsed > 0 else 0

    tables = _parse_html_tables(content)
    return tables, elapsed, completion_tokens, prompt_tokens, tok_per_sec, content


async def main():
    if not VLM_MODEL:
        print("ERROR: Set VLM_MODEL environment variable")
        sys.exit(1)

    short_name = VLM_MODEL.split("/")[-1]
    # Resolve prompt: env override > model-specific > default
    prompt = PROMPT_OVERRIDE or MODEL_PROMPTS.get(VLM_MODEL, MODEL_PROMPTS["_default"])
    print(f"{'='*70}")
    print(f"VLM TABLE BENCHMARK: {short_name}")
    print(f"  Model: {VLM_MODEL}")
    print(f"  URL: {VLM_URL}")
    print(f"  Max tokens: {MAX_TOKENS}")
    print(f"  Prompt: {prompt!r}")
    print(f"{'='*70}")

    # Health check
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(f"{VLM_URL}/health")
            print(f"  Health: {resp.status_code}")
    except Exception as e:
        print(f"  Health check FAILED: {e}")
        sys.exit(1)

    # Warmup (2 requests)
    print("\n--- Warmup (2 requests) ---")
    first_pdf = sorted(BENCH_DIR.glob("*.pdf"))[0]
    doc = fitz.open(str(first_pdf))
    pix = doc[0].get_pixmap(dpi=200)
    warmup_img = pix.tobytes("png")
    doc.close()

    for i in range(2):
        t0 = time.time()
        try:
            tables, _, comp_tok, prompt_tok, tps, content = await vlm_page(warmup_img, prompt, timeout=300.0)
            print(f"  Warmup {i+1}: {time.time()-t0:.1f}s, {prompt_tok} prompt + {comp_tok} completion tok, "
                  f"{tps:.1f} tok/s, {len(tables)} tables, content_len={len(content)}")
            if i == 0 and comp_tok <= 2:
                print(f"  WARNING: Model returned <=2 tokens. Content: {content[:200]!r}")
        except Exception as e:
            print(f"  Warmup {i+1}: FAILED - {repr(e)}")

    # Benchmark
    pdfs = sorted(BENCH_DIR.glob("*.pdf"))
    print(f"\nBenchmarking {len(pdfs)} complex PDFs\n")

    results = []
    total_pages = 0
    total_empty = 0
    total_tables = 0
    total_errors = 0
    all_tps = []

    for pdf in pdfs:
        fname = pdf.name
        doc = fitz.open(str(pdf))
        npages = len(doc)
        print(f"=== {fname} ({npages} pages) ===")

        # Docling baseline
        t0 = time.time()
        try:
            dtables = await docling_extract(str(pdf))
        except Exception as e:
            dtables = []
            print(f"  Docling error: {e}")
        docling_time = time.time() - t0
        print(f"  Docling: {len(dtables)} tables in {docling_time:.1f}s")

        # VLM
        vlm_tables = []
        vlm_time = 0
        empty_pages = 0
        errors = 0
        for pi in range(npages):
            total_pages += 1
            pix = doc[pi].get_pixmap(dpi=200)
            img = pix.tobytes("png")
            try:
                page_tables, elapsed, comp_tok, prompt_tok, tps, content = await vlm_page(img, prompt)
                vlm_time += elapsed
                all_tps.append(tps)

                if comp_tok <= 2 or not content.strip():
                    empty_pages += 1
                    total_empty += 1
                    print(f"  p{pi+1}: EMPTY ({comp_tok} tok, {elapsed:.1f}s)")
                else:
                    for ti, grid in enumerate(page_tables):
                        if grid:
                            vlm_tables.append({"page": pi+1, "table_idx": ti, "cells_2d": grid})
                            total_tables += 1
                    if not page_tables:
                        # Content returned but no tables parsed
                        print(f"  p{pi+1}: {comp_tok} tok, {elapsed:.1f}s, NO TABLES PARSED. First 150 chars: {content[:150]!r}")
                    else:
                        print(f"  p{pi+1}: {comp_tok} tok, {elapsed:.1f}s, {tps:.1f} tok/s, {len(page_tables)} tables")
            except Exception as e:
                errors += 1
                total_errors += 1
                print(f"  p{pi+1}: ERROR - {repr(e)}")
        doc.close()

        print(f"  VLM {short_name}: {len(vlm_tables)} tables in {vlm_time:.1f}s, "
              f"{empty_pages}/{npages} empty" +
              (f", {errors} errors" if errors else ""))

        # Compare overlapping pages
        comparisons = []
        docling_pages = {}
        for dt in dtables:
            docling_pages.setdefault(dt["page"], []).append(dt)

        for vt in vlm_tables:
            pg = vt["page"]
            if pg in docling_pages:
                for dt in docling_pages[pg]:
                    dq = compute_table_quality(dt["cells_2d"])
                    vq = compute_table_quality(vt["cells_2d"])
                    diff = round(vq.overall_score - dq.overall_score, 3)
                    winner = "VLM" if diff > 0.05 else ("Docling" if diff < -0.05 else "TIE")
                    dd = f"{len(dt['cells_2d'])}x{max(len(r) for r in dt['cells_2d'])}"
                    vd = f"{len(vt['cells_2d'])}x{max(len(r) for r in vt['cells_2d'])}"
                    print(f"  Page {pg}: Docling {dq.overall_score:.3f} ({dq.grade}) vs "
                          f"VLM {vq.overall_score:.3f} ({vq.grade}) [{diff:+.3f}] -> {winner}")
                    comparisons.append({
                        "page": pg, "docling_score": dq.overall_score, "vlm_score": vq.overall_score,
                        "diff": diff, "winner": winner, "docling_dims": dd, "vlm_dims": vd,
                        "docling_grade": dq.grade, "vlm_grade": vq.grade,
                    })
                docling_pages.pop(pg)

        # VLM-only pages (tables not found by Docling)
        compared_pages = {c["page"] for c in comparisons}
        for vt in vlm_tables:
            if vt["page"] not in compared_pages:
                vq = compute_table_quality(vt["cells_2d"])
                vd = f"{len(vt['cells_2d'])}x{max(len(r) for r in vt['cells_2d'])}"
                print(f"  Page {vt['page']}: VLM-only ({vd}) -- {vq.overall_score:.3f} {vq.grade}")

        results.append({
            "file": fname, "docling_time": round(docling_time, 1),
            "vlm_time": round(vlm_time, 1),
            "docling_tables": len(dtables), "vlm_tables": len(vlm_tables),
            "empty_pages": empty_pages, "total_pages": npages,
            "errors": errors, "comparisons": comparisons,
        })
        print()

    # Summary
    avg_tps = sum(all_tps) / len(all_tps) if all_tps else 0
    success_rate = (total_pages - total_empty - total_errors) / total_pages * 100 if total_pages else 0
    total_vlm_time = sum(r["vlm_time"] for r in results)

    # Count comparison winners
    all_comparisons = [c for r in results for c in r["comparisons"]]
    vlm_wins = sum(1 for c in all_comparisons if c["winner"] == "VLM")
    docling_wins = sum(1 for c in all_comparisons if c["winner"] == "Docling")
    ties = sum(1 for c in all_comparisons if c["winner"] == "TIE")
    avg_vlm_score = sum(c["vlm_score"] for c in all_comparisons) / len(all_comparisons) if all_comparisons else 0
    avg_docling_score = sum(c["docling_score"] for c in all_comparisons) / len(all_comparisons) if all_comparisons else 0

    print(f"{'='*70}")
    print(f"SUMMARY: {short_name}")
    print(f"{'='*70}")
    print(f"  Total pages processed: {total_pages}")
    print(f"  Success rate: {success_rate:.0f}% ({total_pages - total_empty - total_errors}/{total_pages})")
    print(f"  Empty responses: {total_empty}/{total_pages} ({100*total_empty/total_pages:.0f}%)" if total_pages else "")
    print(f"  Errors: {total_errors}/{total_pages}")
    print(f"  Tables found: {total_tables}")
    print(f"  Avg throughput: {avg_tps:.1f} tok/s")
    print(f"  Total VLM time: {total_vlm_time:.1f}s")
    print(f"  Comparisons: {len(all_comparisons)} (VLM wins: {vlm_wins}, Docling wins: {docling_wins}, Ties: {ties})")
    print(f"  Avg quality: VLM={avg_vlm_score:.3f} vs Docling={avg_docling_score:.3f}")
    print(f"{'='*70}")

    # Save results
    safe_name = short_name.replace("/", "_").replace(" ", "_").lower()
    out_path = f"/tmp/vlm_bench_{safe_name}.json"
    out = {
        "model": VLM_MODEL,
        "short_name": short_name,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "config": {"vlm_url": VLM_URL, "max_tokens": MAX_TOKENS, "prompt": prompt},
        "summary": {
            "total_pages": total_pages,
            "success_rate_pct": round(success_rate, 1),
            "empty_responses": total_empty,
            "errors": total_errors,
            "tables_found": total_tables,
            "avg_tok_per_sec": round(avg_tps, 1),
            "total_vlm_time_s": round(total_vlm_time, 1),
            "comparisons": len(all_comparisons),
            "vlm_wins": vlm_wins,
            "docling_wins": docling_wins,
            "ties": ties,
            "avg_vlm_quality": round(avg_vlm_score, 3),
            "avg_docling_quality": round(avg_docling_score, 3),
        },
        "results": results,
    }
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nSaved: {out_path}")


asyncio.run(main())
